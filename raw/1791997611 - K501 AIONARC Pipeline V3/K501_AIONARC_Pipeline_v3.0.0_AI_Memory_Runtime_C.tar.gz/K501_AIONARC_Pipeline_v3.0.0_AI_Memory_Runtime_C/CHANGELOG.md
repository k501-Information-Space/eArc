# Changelog

## v3.0.0-alpha.0 — 2026-10-14

- Introduced C11 AI Memory Runtime candidate with explicit CLI, store schema and frame package.
- Retained QH256 v2.0 core source and 32-byte serialization; added application profile `QH256-K501-AIONARC-MEMORY-V3A0` without modifying QH256 operators.
- Added append-only frame output, state/record/object identity checks, parent-chain validation, derived text capture, per-object QH256 in `INDEX.tsv`, exact lexical retrieval, trace/history/diff/source verification, Gateway reconstruction and manifest verification.
- Defined a proof-before-state contract with staged candidate generation, read-back validation, durable proof and post-proof state commit.
- Added operator and format documentation with explicit scope limits and open claims.
- No llama.cpp integration, embeddings, semantic retrieval or model-based fact promotion.

This is an alpha candidate. It is not canonical and has not been host-validated on the user's workstation.
