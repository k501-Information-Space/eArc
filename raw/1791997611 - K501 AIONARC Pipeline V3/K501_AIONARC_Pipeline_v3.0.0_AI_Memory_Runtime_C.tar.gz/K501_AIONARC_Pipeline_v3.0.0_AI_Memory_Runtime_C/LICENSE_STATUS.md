# License and source status

No new licensing terms are asserted by this package.

The source files under `include/qh256.h`, `src/qh256.c`, `src/sha256.h`, and `src/sha256.c` were copied byte-for-byte from the referenced K501 AIONARC Pipeline v2.1.0 Alpha Operational C package. The original release archive and SHA-256 are retained under `reference/`.

The referenced v2.1-C package contains a `LICENSE_STATUS.md` stating that no new licensing terms are asserted and that canonical QH256 source must retain the licensing and copyright metadata of its canonical repository/release. Before a public release or redistribution, the project owner must resolve the license boundary and preserve any applicable upstream notices. This package does not infer MIT, GPL, or another license from repository convention.
