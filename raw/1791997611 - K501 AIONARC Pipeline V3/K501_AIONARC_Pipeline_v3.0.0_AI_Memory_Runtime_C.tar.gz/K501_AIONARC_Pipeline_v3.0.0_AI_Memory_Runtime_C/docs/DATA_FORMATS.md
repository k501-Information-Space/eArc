# V3 data formats and identity domains

All frame files are UTF-8 tab-separated text with LF line endings, except content itself which is Base64-encoded in `TEXT.tsv`. Paths are Base64-encoded in durable machine fields because Unix paths can include spaces, tabs, control bytes other than NUL, or non-ASCII byte sequences. Terminal-facing output shows a backslash-escaped path as well as Base64 where relevant. Base64 is not encryption.

## Object identity domains

- **`object_id`** — SHA-256 over a domain-separated tuple: `OBJECT_ID_DOMAIN || 0x00 || root_id || 0x00 || relative_path || 0x00 || object_type`. The root ID, relative path and object type contribute to identity. Path change means identity change under this profile.
- **`content_sha256`** — SHA-256 of regular-file bytes; for symlinks, SHA-256 of the link-target bytes returned by `readlink`. Non-byte-bearing object types are `-`.
- **`record_hash`** — SHA-256 of the serialized V3 object record payload containing root ID, Base64 relative path, object type, mode, size, mtime seconds/nanoseconds and `content_sha256`.
- **`state_sha256`** — SHA-256 of the exact serialized `STATE.tsv` bytes.
- **`chain_sha256`** — SHA-256 using domain `K501-AIONARC-MEMORY-CHAIN-V3A0\0`, the prior frame's raw chain digest (32 zero bytes for initial), then current state hash raw bytes. This is V3-specific and is not claimed to match the v2.1 Alpha-C state/chain formula.
- **`text_sha256`** — SHA-256 of extracted UTF-8 text bytes; not a source file digest and not canonical state.
- **Artifact file hashes** — ordinary SHA-256 of exact bytes of `FRAME.tsv`, `TEXT.tsv`, `INDEX.tsv`, `TRANSITION.tsv`, `GATEWAY.tsv` and `QH256.hex`, bound by `PROOF.tsv` and/or `MANIFEST.sha256`.
- **`QH256.hex`** — 64 lowercase hex characters representing the actual QH256 v2 32-byte serialized value plus header lines identifying core and mapping profile. It is neither a SHA-256 digest nor a complete object history.

## `STORE_FORMAT.txt`

Marks a directory as a V3 store using `K501-AIONARC-AI-MEMORY-STORE-V3A0`. The store is non-canonical and contains derived runtime frames. `init` refuses to overwrite an existing path.

## `STATE.tsv`

Contains a schema line, root/frame ID, sequence, parent frame ID, parent state digest, object count, and a sorted list of object records. Each `O` line contains object ID, record hash, content digest, type, octal mode, size, mtime seconds/nanoseconds, and Base64 relative path. It contains no extracted prose and no LLM output.

## `TEXT.tsv`

Each `T` line carries object ID, source `content_sha256`, `text_sha256`, extractor ID, Base64 relative path, text byte length and Base64 text. The decoder recomputes text hash and validates metadata bindings. Plain UTF-8 capture preserves bytes; PDF extraction is an explicitly named transform (`pdftotext-layout-utf8-v1`) and therefore is derived.

## `INDEX.tsv`

Header fields identify `DERIVED` status and mapping profile. Each `I` row contains object ID, record hash, content hash, object type, text hash or `-`, extractor or `-`, retrieval availability (`SEARCHABLE`/`STRUCTURAL_ONLY`), Base64 relative path, text status and per-object serialized QH256 hex. The complete index is derived from the candidate state plus captured text; it may be rebuilt.

## `TRANSITION.tsv`

Stores parent frame reference, event count, added/removed/content_changed/metadata_changed/unchanged counts, and deterministic event rows. During validation, V3 reconstructs expected events by comparing current state to its verified parent and checks the stored event sequence field-for-field.

## `GATEWAY.tsv`

Stores orientation role/status, frame/root/sequence binding, names of frame artifacts and the top-level object entries. V3 reconstructs the header and entry sequence from the frame; the Gateway cannot rewrite the source state.

## `FRAME.tsv`

Binds V3 implementation version, non-canonical candidate status, created UTC time according to local POSIX clock, time-source label, root ID, frame ID, sequence, parent reference, object/event counts, state hash, chain hash and artifact names/profile.

## `PROOF.tsv`

Records result `PASS`, the contract ID, frame/state/chain metadata, hashes for key outputs, named checks and a non-claim. It is written and fsync'ed before `STATE.candidate` becomes `STATE.tsv`.

## `MANIFEST.sha256`

Contains hashes for the eight frame artifacts: FRAME, Gateway, index, proof, QH256, state, text and transition. The manifest excludes itself to avoid self-referential hashing.

## Hashes are integrity indicators, not signatures

An attacker with write permission can replace artifacts and recompute dependent hashes and manifests. V3 does not sign records, store them remotely, or defend against an adversarial operator controlling the whole store. Protect the store with filesystem permissions and independent backups if that threat matters.
