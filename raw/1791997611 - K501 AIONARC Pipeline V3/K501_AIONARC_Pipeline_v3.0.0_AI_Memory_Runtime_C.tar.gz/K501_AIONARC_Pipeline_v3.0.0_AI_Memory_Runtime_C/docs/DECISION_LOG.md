# Decision Log — V3 alpha

## D-001 — C is the standard

**Decision:** Pipeline runtime is implemented in C11; no Python is required for runtime.  
**Reason:** native integration path with the existing QH256 C reference and a reproducible terminal executable.

## D-002 — Do not redefine QH256 v2

**Decision:** retain QH256 v2 core source and 32-byte serialization; expand only the versioned application mapping profile.  
**Reason:** state algebra and memory/application ontology are different layers.

## D-003 — V3 object identity is explicitly versioned

**Decision:** V3 uses a new object-record schema and chain domain.  
**Reason:** v2.1-C's open Python/C identity and canonical-record compatibility gates are not to be silently inherited or declared closed. V3 does not claim byte parity with v2.1 state/record artefacts.

## D-004 — Proof before committed state

**Decision:** staging artifacts are re-read and validated; `PROOF.tsv` is flushed before `STATE.candidate` becomes `STATE.tsv`; the final frame directory is promoted after manifest generation.  
**Reason:** failure must not masquerade as a committed frame.

## D-005 — No silent branch selection

**Decision:** `latest` refuses ambiguous tips.  
**Reason:** directory order or clock time must not silently choose ancestry.

## D-006 — Structural memory before semantic inference

**Decision:** V3 captures supported text and does exact lexical search only; no llama.cpp integration or embeddings.  
**Reason:** establish source-bound temporal memory first and keep model-generated interpretation outside stored structural state.

## D-007 — Full original v2.1-C release kept as reference

**Decision:** include the original release ZIP and SHA-256 under `reference/`.  
**Reason:** traceability and reproduction; does not settle the upstream license status.

## D-008 — Alpha status retained

**Decision:** release label is `3.0.0-alpha.0`, `NON-CANONICAL`.  
**Reason:** package tests in this build environment are not equivalent to operator-host validation, independent review, production scale testing or license resolution.
