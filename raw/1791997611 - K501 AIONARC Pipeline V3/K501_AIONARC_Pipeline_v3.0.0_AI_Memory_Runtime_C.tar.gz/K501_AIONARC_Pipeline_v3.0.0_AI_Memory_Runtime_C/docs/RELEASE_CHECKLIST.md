# Release checklist — not all gates are PASS

This checklist is a gate template. A checkbox is not considered completed by its presence in this file.

## Package

- [x] Source package exists and has `Makefile`, CLI implementation, qh256/sha256 source, operator manual, format docs, proof contract, mapping profile and tests.
- [x] v2.1-C reference archive included verbatim and checksum verification scripted.
- [x] Local C11 build/test completed in package-build environment.
- [x] ASan/UBSan test suite passed after fixing the detected leak.
- [ ] Operator has run `make test` on target Debian 13 workstation.
- [ ] Operator has run the manual quickstart on a new disposable store.
- [ ] Operator has reviewed every QH256 mapping cell and the state/transition file format.
- [ ] Upstream license boundary reviewed and permission/notice requirements resolved.

## Operational release blockers

- [ ] Stress/load test on target resource limits and intended corpus size.
- [ ] Interrupted-run/power-loss tests over the candidate/proof/state/promote boundary.
- [ ] Explicit backup/restore verification on target host.
- [ ] Review all error paths, numeric parser bounds and hostile/local file behaviours.
- [ ] Independent technical review of Proof Before State claims and implementation.
- [ ] Versioned and tested interface contract before any llama.cpp adapter.
- [ ] Explicit owner gate to promote from non-canonical alpha candidate.

## No-go items

- Do not make the package canonical merely because a test prints PASS.
- Do not claim the new V3 record is byte-compatible with v2.1-C.
- Do not overwrite or migrate a v2.1 workspace/index automatically.
- Do not claim semantic memory, embedding retrieval or LLM integration in this version.
