# Security, failure model and limitations

## Threats this alpha tries to detect

- Source file byte changes during observation (double hash plus metadata checks).
- Directory membership/metadata changes noticed during traversal.
- Symlink target/metadata change noticed during repeated read.
- Candidate state serialization/hash/identity mismatch.
- Missing/reordered/tampered text, index, transition, Gateway, QH or manifest artifacts.
- Incorrect parent sequence/root/state references and parent chain digest.
- Reused frame ID or multiple tips when the operator asks for `latest`.
- Source/store overlap that could feed generated runtime data back as input.

## Threats not addressed fully

- A malicious process with write access to the whole store can replace files and recompute hashes/proof/manifest; no signature or remote witness exists.
- A normal filesystem walk is not a single atomic snapshot. V3 checks for common concurrent modifications but cannot exclude every race or malicious filesystem behaviour.
- Metadata semantics vary by filesystem. `mtime` is recorded for comparison and provenance, not treated as a universal clock.
- No multi-process locking or concurrent writer protocol exists. Operate as a single writer.
- No encryption-at-rest or access control layer is implemented. Use OS file permissions.
- No guarantee that extracted text captures every meaning, table, layout, OCR text or embedded image of the original file.
- No semantic query, embeddings, reranking, model grounding prompt or generated-claim validation exists in V3 alpha.
- Hash equality provides byte-level integrity evidence, not truth, authorship or scientific validity.

## Safe operation

Begin on copied data, use a new empty store, and run the test suite. Do not run on `/home/hirn/K501/workspace`, `workspace_evo`, active Git repositories or a canonical source directory without a separate approved read-only inventory and scope gate. This generated package does not touch those paths.

Keep interrupted `.stage-*` directories as evidence until reviewed. Do not auto-promote, overwrite, remove or rename them. Back up stores by copying to a new path; validate source and destination independently.
