# Source and evidence register

## Source components included

1. `K501_AIONARC_Pipeline_v2.1.0_Alpha_Operational_C.zip` included verbatim as `reference/K501_AIONARC_Pipeline_v2.1.0_Alpha_Operational_C.zip`. The stored checksum in `reference/SHA256SUMS.txt` is `f64a796989afb41da19b5aafa4a5d3b2829198a1f6bc2283abad5710644f0230`.
2. `include/qh256.h`, `src/qh256.c`, `src/sha256.h` and `src/sha256.c` have been compared byte-for-byte to the respective files in the unpacked v2.1-C archive during package preparation. Their origin is that release; the v2.1-C licensing status remains unresolved and is not reinterpreted here.
3. The v2.1-C mapping profile `QH256-AIONARC-OBJECT-0.1` is retained as historical input. V3 preserves its assigned 0–15 coded behaviour where documented, records some unresolved legacy slots as UNKNOWN, and defines a new separate profile for cells 16–63. This is not a claim that V3’s object record bytes match v2.1-C.
4. Frame/index/Gateway concepts are reimplemented under V3 file schemas. The v2.1-C indexer and frame engine are not imported as execution dependencies; their historical behaviours and previously found mutation/overwrite risks are described in project materials, and V3 uses its own narrow staged commit path.

## Project source facts and limits

- QH256 v2.0 is the formal 128 two-bit cell / 256-bit / 32-byte state core, not an archive or semantic interpreter. Public source: https://github.com/k501-Information-Space/QH256
- The v2.1.0 Alpha-C pipeline is an operational alpha with previously documented open Python/C parity and exact record-compatibility questions. V3 uses a new schema/version namespace rather than marking those gates closed.
- The historical local eArc runs and current index caveat are preserved as project history. V3 does not alter the user's local `workspace_evo` or current index.
- This package was authored and tested in the current package-building container on Linux. It has not run on the operator's actual Debian 13/HP xw8600 workstation in this turn.

## Evidence classes

- **FACT (package-build environment):** C compile completed using C11 with `-Wall -Wextra -Wpedantic -Wno-misleading-indentation -Werror`; the integration test script passed; AddressSanitizer and UndefinedBehaviorSanitizer build/test run passed with no reported leak after one leak fix; archived v2.1-C ZIP checksum matched.
- **SPECIFICATION:** behaviours described in docs and proof contract.
- **DERIVED:** state/index/text/proof artefacts created by V3 scans.
- **PROPOSAL:** the V3 mapping and runtime contract are proposed for owner review; V3 remains non-canonical.
- **OPEN:** license boundary, target-host test, independent review, stress/scale testing, integration release, future llama.cpp interface and semantic retrieval.
