#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
make all
printf '\nBuilt: %s\n' "$PWD/build/k501-memory"
