#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
if [ -f SHA256SUMS.txt ]; then sha256sum -c SHA256SUMS.txt; else echo 'SHA256SUMS.txt not found (run make package-checksum in the release workspace)' >&2; exit 2; fi
make verify-reference
make test
