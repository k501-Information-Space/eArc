#include "sha256.h"
#include <string.h>
static const uint32_t K[64]={
0x428a2f98u,0x71374491u,0xb5c0fbcfu,0xe9b5dba5u,0x3956c25bu,0x59f111f1u,0x923f82a4u,0xab1c5ed5u,
0xd807aa98u,0x12835b01u,0x243185beu,0x550c7dc3u,0x72be5d74u,0x80deb1feu,0x9bdc06a7u,0xc19bf174u,
0xe49b69c1u,0xefbe4786u,0x0fc19dc6u,0x240ca1ccu,0x2de92c6fu,0x4a7484aau,0x5cb0a9dcu,0x76f988dau,
0x983e5152u,0xa831c66du,0xb00327c8u,0xbf597fc7u,0xc6e00bf3u,0xd5a79147u,0x06ca6351u,0x14292967u,
0x27b70a85u,0x2e1b2138u,0x4d2c6dfcu,0x53380d13u,0x650a7354u,0x766a0abbu,0x81c2c92eu,0x92722c85u,
0xa2bfe8a1u,0xa81a664bu,0xc24b8b70u,0xc76c51a3u,0xd192e819u,0xd6990624u,0xf40e3585u,0x106aa070u,
0x19a4c116u,0x1e376c08u,0x2748774cu,0x34b0bcb5u,0x391c0cb3u,0x4ed8aa4au,0x5b9cca4fu,0x682e6ff3u,
0x748f82eeu,0x78a5636fu,0x84c87814u,0x8cc70208u,0x90befffau,0xa4506cebu,0xbef9a3f7u,0xc67178f2u};
static uint32_t rotr(uint32_t x,unsigned n){return (x>>n)|(x<<(32u-n));}
static uint32_t ch(uint32_t x,uint32_t y,uint32_t z){return (x&y)^(~x&z);}
static uint32_t maj(uint32_t x,uint32_t y,uint32_t z){return (x&y)^(x&z)^(y&z);}
static uint32_t bs0(uint32_t x){return rotr(x,2u)^rotr(x,13u)^rotr(x,22u);}
static uint32_t bs1(uint32_t x){return rotr(x,6u)^rotr(x,11u)^rotr(x,25u);}
static uint32_t ss0(uint32_t x){return rotr(x,7u)^rotr(x,18u)^(x>>3u);}
static uint32_t ss1(uint32_t x){return rotr(x,17u)^rotr(x,19u)^(x>>10u);}
static uint32_t be32(const uint8_t *p){return ((uint32_t)p[0]<<24u)|((uint32_t)p[1]<<16u)|((uint32_t)p[2]<<8u)|(uint32_t)p[3];}
static void putbe32(uint8_t *p,uint32_t x){p[0]=(uint8_t)(x>>24u);p[1]=(uint8_t)(x>>16u);p[2]=(uint8_t)(x>>8u);p[3]=(uint8_t)x;}
static void compress_block(sha256_ctx *c,const uint8_t b[64]){
 uint32_t w[64],a,bv,d,e,f,g,h,t1,t2; uint32_t cc; size_t i;
 for(i=0;i<16u;++i)w[i]=be32(&b[i*4u]);
 for(i=16u;i<64u;++i)w[i]=ss1(w[i-2u])+w[i-7u]+ss0(w[i-15u])+w[i-16u];
 a=c->h[0];bv=c->h[1];cc=c->h[2];d=c->h[3];e=c->h[4];f=c->h[5];g=c->h[6];h=c->h[7];
 for(i=0;i<64u;++i){t1=h+bs1(e)+ch(e,f,g)+K[i]+w[i];t2=bs0(a)+maj(a,bv,cc);h=g;g=f;f=e;e=d+t1;d=cc;cc=bv;bv=a;a=t1+t2;}
 c->h[0]+=a;c->h[1]+=bv;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;c->h[5]+=f;c->h[6]+=g;c->h[7]+=h;
}
void sha256_init(sha256_ctx*c){c->h[0]=0x6a09e667u;c->h[1]=0xbb67ae85u;c->h[2]=0x3c6ef372u;c->h[3]=0xa54ff53au;c->h[4]=0x510e527fu;c->h[5]=0x9b05688cu;c->h[6]=0x1f83d9abu;c->h[7]=0x5be0cd19u;c->bitlen=0u;c->used=0u;}
void sha256_update(sha256_ctx*c,const uint8_t*d,size_t n){while(n){size_t take=64u-c->used;if(take>n)take=n;memcpy(c->block+c->used,d,take);c->used+=take;d+=take;n-=take;c->bitlen+=(uint64_t)take*8u;if(c->used==64u){compress_block(c,c->block);c->used=0u;}}}
void sha256_final(sha256_ctx*c,uint8_t out[32]){size_t i;c->block[c->used++]=0x80u;if(c->used>56u){while(c->used<64u)c->block[c->used++]=0u;compress_block(c,c->block);c->used=0u;}while(c->used<56u)c->block[c->used++]=0u;for(i=0;i<8u;++i)c->block[56u+i]=(uint8_t)(c->bitlen>>(56u-8u*i));compress_block(c,c->block);for(i=0;i<8u;++i)putbe32(&out[i*4u],c->h[i]);}
void sha256_bytes(const uint8_t*d,size_t n,uint8_t out[32]){sha256_ctx c;sha256_init(&c);sha256_update(&c,d,n);sha256_final(&c,out);}
