#!/bin/bash
set -euo pipefail
BIN=${1:-"$(cd "$(dirname "$0")/.." && pwd)/build/k501-memory"}
TMP=$(mktemp -d "k501-v3-test.XXXXXX")
trap 'rm -rf "$TMP"' EXIT
SRC="$TMP/source corpus"
STORE="$TMP/memory store"
mkdir -p "$SRC/docs with spaces" "$SRC/config"
cat > "$SRC/README.md" <<'TXT'
K501 AI Memory Runtime proof before state.
A source record is not the same as derived meaning.
TXT
cat > "$SRC/docs with spaces/Übersicht.txt" <<'TXT'
Object identity depends on root, path and type.
History must remain append-only. Verify before retrieval.
TXT
printf '{"proof_before_state":true,"runtime":"K501"}\n' > "$SRC/config/runtime.json"
printf '\001\002\003\377' > "$SRC/binary.dat"
ln -s 'docs with spaces/Übersicht.txt' "$SRC/document-link"

"$BIN" qh256-test | grep -q 'QH256 CORE TEST PASS'
"$BIN" init "$STORE" | grep -q 'INIT PASS'
"$BIN" scan "$SRC" "$STORE" k501-test-root frame-001 none | grep -q 'proof_before_state=PASS'
"$BIN" verify "$STORE" frame-001 | grep -q 'VERIFY PASS'
"$BIN" verify-source "$STORE" frame-001 "$SRC" | grep -q 'VERIFY SOURCE PASS'
"$BIN" query "$STORE" latest 'proof before state' | grep -q 'PATH=README.md'
"$BIN" query "$STORE" latest 'object identity path type' | grep -q 'Übersicht.txt' 
ID=$(awk -F '\t' '$1=="O" && $10=="UkVBRE1FLm1k" {print $2; exit}' "$STORE/frames/frame-001/STATE.tsv")
test -n "$ID"
"$BIN" trace "$STORE" latest "$ID" | grep -q "object_id=$ID"
"$BIN" history "$STORE" "$ID" | grep -q 'FRAMES.*1'
"$BIN" diff "$STORE" frame-001 | grep -q 'event_count'

printf '\nUpdated README content for frame two.\n' >> "$SRC/README.md"
printf 'additional object for transition test\n' > "$SRC/new-note.txt"
"$BIN" scan "$SRC" "$STORE" k501-test-root frame-002 frame-001 | grep -q 'proof_before_state=PASS'
"$BIN" verify "$STORE" frame-002 | grep -q 'VERIFY PASS'
"$BIN" verify "$STORE" frame-001 | grep -q 'VERIFY PASS'
"$BIN" verify-source "$STORE" frame-002 "$SRC" | grep -q 'VERIFY SOURCE PASS'
"$BIN" history "$STORE" "$ID" | grep -q 'FRAMES.*2'
"$BIN" diff "$STORE" frame-002 | grep -q 'CONTENT_CHANGED'

if "$BIN" scan "$SRC" "$STORE" k501-test-root frame-002 latest >/dev/null 2>&1; then echo 'FAIL: reused frame ID was accepted' >&2; exit 1; fi

TAMPER="$TMP/tampered store"
cp -a "$STORE" "$TAMPER"
printf '\n' >> "$TAMPER/frames/frame-002/INDEX.tsv"
if "$BIN" verify "$TAMPER" frame-002 >/dev/null 2>&1; then echo 'FAIL: tampered index was accepted' >&2; exit 1; fi

DRIFT="$TMP/drift corpus"
cp -a "$SRC" "$DRIFT"
"$BIN" verify-source "$STORE" frame-002 "$DRIFT" | grep -q 'VERIFY SOURCE PASS'
printf 'local source edit\n' >> "$DRIFT/README.md"
if "$BIN" verify-source "$STORE" frame-002 "$DRIFT" >/dev/null 2>&1; then echo 'FAIL: source drift was accepted' >&2; exit 1; fi

BRANCH="$TMP/branch store"
"$BIN" init "$BRANCH" >/dev/null
"$BIN" scan "$SRC" "$BRANCH" branch-root b0 none >/dev/null
"$BIN" scan "$SRC" "$BRANCH" branch-root b1 b0 >/dev/null
"$BIN" scan "$SRC" "$BRANCH" branch-root b2 b0 >/dev/null
if "$BIN" latest "$BRANCH" >/dev/null 2>&1; then echo 'FAIL: ambiguous branch tip was silently selected' >&2; exit 1; fi

if "$BIN" scan "$SRC" "$STORE" k501-test-root overlap-001 none >/dev/null 2>&1; then echo 'FAIL: parent=none on populated store was accepted' >&2; exit 1; fi

printf 'K501 V3 TEST SUITE: PASS\n'
printf 'checks: QH256 core; initial frame; proof-before-state; state/record identity; index and Gateway reconstruction; exact lexical retrieval; trace; history; transition reconstruction; second-frame update; source parity; repeated frame ID rejection; tamper rejection; source-drift rejection; ambiguous branch refusal\n'
